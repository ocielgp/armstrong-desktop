create definer = root@`%` view sac_view as
select `o`.`_id`                                                                                  AS `Orden`,
       concat(if((length(hour(`o`.`createdTime`)) > 1), '', '0'), hour(`o`.`createdTime`), ':00') AS `createdTime`,
       concat(hour(`o`.`takedTime`), ':00')                                                       AS `takedTime`,
       cast(`o`.`createdAt` as date)                                                              AS `Fecha`,
       `o`.`total`                                                                                AS `total`,
       `o`.`status`                                                                               AS `status`,
       `o`.`payment_method`                                                                       AS `MetodoPago`,
       `d`.`name`                                                                                 AS `Runner`,
       concat(concat(`c`.`name`, '-'), right(`c`.`_id`, 3))                                       AS `Cliente`,
       `s`.`name`                                                                                 AS `Sucursal`,
       `s`.`city`                                                                                 AS `Ciudad`,
       '-'                                                                                        AS `Producto`,
       0                                                                                          AS `quantity`,
       0                                                                                          AS `id_item`,
       `s`.`commission`                                                                           AS `commission`,
       `o`.`motivoCancelacion`                                                                    AS `motivoCancelacion`,
       cast(`o`.`createdTime` as time)                                                            AS `HoraCreacion`,
       cast(`o`.`updatedAt` as time)                                                              AS `HoraActualizacion`,
       concat(timediff(cast(`o`.`updatedAt` as time), cast(`o`.`createdTime` as time)), '')       AS `Tiempo`
from (((`coyotebd`.`orders` `o` left join `coyotebd`.`dealers` `d` on ((`d`.`_id` = `o`.`id_dealers`))) left join `coyotebd`.`customers` `c` on ((`c`.`_id` = `o`.`id_customers`)))
         left join `coyotebd`.`branch_offices` `s` on ((`s`.`_id` = `o`.`id_branch_offices`)));

