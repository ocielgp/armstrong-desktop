create definer = sacuser@`%` view listas as
select `coyotebd`.`branch_offices`.`_id`                   AS `_id`,
       `coyotebd`.`branch_offices`.`address`               AS `address`,
       `coyotebd`.`branch_offices`.`city`                  AS `city`,
       `coyotebd`.`branch_offices`.`commission`            AS `commission`,
       `coyotebd`.`branch_offices`.`createdAt`             AS `createdAt`,
       `coyotebd`.`branch_offices`.`email`                 AS `email`,
       `coyotebd`.`branch_offices`.`id_general_categories` AS `id_general_categories`,
       `coyotebd`.`branch_offices`.`image`                 AS `image`,
       `coyotebd`.`branch_offices`.`latitude`              AS `latitude`,
       `coyotebd`.`branch_offices`.`length`                AS `length`,
       `coyotebd`.`branch_offices`.`name`                  AS `name`,
       `coyotebd`.`branch_offices`.`phone`                 AS `phone`,
       `coyotebd`.`branch_offices`.`postal_code`           AS `postal_code`,
       `coyotebd`.`branch_offices`.`schedule`              AS `schedule`,
       `coyotebd`.`branch_offices`.`state`                 AS `state`,
       `coyotebd`.`branch_offices`.`updatedAt`             AS `updatedAt`
from `coyotebd`.`branch_offices`
where (`coyotebd`.`branch_offices`.`name` in
       ('PAL antojo', 'Crunchy Wings', 'Mr. Elote', 'Mr. Donkey', 'Tacos Doña Evis "Cheque"""', 'PIZZARELLA',
        'LONCHERIA LOS BANCOS', 'MARISCOS EL BARCO.', 'RINCÓN AZTECA', 'TACOS AYALA.', 'SNACK MAIZE',
        'Antojitos Mexicanos Male', 'LA COCINA DEL CHEF', 'TACOS SUAVES EL PATRÓN', 'LOS MAKIS', 'BURGER & WINGS'));

