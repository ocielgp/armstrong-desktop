create definer = root@`%` view sac_view_detalle as
select `o`.`_id`                                            AS `Orden`,
       cast(`o`.`createdAt` as date)                        AS `Fecha`,
       `o`.`status`                                         AS `status`,
       `s`.`name`                                           AS `Sucursal`,
       `i`.`name`                                           AS `Producto`,
       concat(concat(`c`.`name`, '-'), right(`c`.`_id`, 3)) AS `Cliente`,
       sum(`i`.`quantity`)                                  AS `Cantidad`,
       `o`.`total`                                          AS `total`
from (((`coyotebd`.`orders` `o` left join `coyotebd`.`branch_offices` `s` on ((`s`.`_id` = `o`.`id_branch_offices`))) left join `coyotebd`.`order_item` `i` on ((`i`.`id_order` = `o`.`_id`)))
         left join `coyotebd`.`customers` `c` on ((`c`.`_id` = `o`.`id_customers`)))
group by `s`.`name`, `o`.`_id`, `i`.`name`;

