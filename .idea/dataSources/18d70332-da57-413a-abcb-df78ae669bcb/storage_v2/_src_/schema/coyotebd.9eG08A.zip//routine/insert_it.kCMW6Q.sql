create
    definer = root@localhost procedure insert_it()
BEGIN
    DECLARE varcount INT DEFAULT 1;
    DECLARE varmax INT DEFAULT 100;

    WHILE varcount <= varmax
        DO
            INSERT INTO coyoteBD.dealer_activity
            SELECT ELT(0.5 + RAND() * 6, '6082f8cf66bda84ff29c8d83', '602455b5d3a48567b837d861',
                       '604fb758d3ef39716a1ac037', '60244fe2d3a48567b837d84f', '60244ee4d3a48567b837d84e',
                       '60245056d3a48567b837d850')
                 , '2021-05-23'
                 , SEC_TO_TIME(
                    FLOOR(
                                TIME_TO_SEC('13:00:00') + RAND() * (
                                TIME_TO_SEC(TIMEDIFF('15:00:00', '13:00:00'))
                                )
                        )
                )
                 , SEC_TO_TIME(
                    FLOOR(
                                TIME_TO_SEC('16:00:00') + RAND() * (
                                TIME_TO_SEC(TIMEDIFF('22:00:00', '16:00:00'))
                                )
                        )
                );
            SET varcount = varcount + 1;
        END WHILE;

END;

