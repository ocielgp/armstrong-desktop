create definer = root@`%` view ordenes as
select `coyotebd`.`orders`.`_id`               AS `_id`,
       `coyotebd`.`orders`.`createdAt`         AS `createdAt`,
       `coyotebd`.`orders`.`date`              AS `date`,
       `coyotebd`.`orders`.`id_addresses`      AS `id_addresses`,
       `coyotebd`.`orders`.`id_branch_offices` AS `id_branch_offices`,
       `coyotebd`.`orders`.`id_customers`      AS `id_customers`,
       `coyotebd`.`orders`.`id_dealers`        AS `id_dealers`,
       `coyotebd`.`orders`.`id_tokenFCM`       AS `id_tokenFCM`,
       `coyotebd`.`orders`.`notes`             AS `notes`,
       `coyotebd`.`orders`.`payment_method`    AS `payment_method`,
       `coyotebd`.`orders`.`products`          AS `products`,
       `coyotebd`.`orders`.`status`            AS `status`,
       `coyotebd`.`orders`.`total`             AS `total`,
       `coyotebd`.`orders`.`updatedAt`         AS `updatedAt`
from `coyotebd`.`orders`;

