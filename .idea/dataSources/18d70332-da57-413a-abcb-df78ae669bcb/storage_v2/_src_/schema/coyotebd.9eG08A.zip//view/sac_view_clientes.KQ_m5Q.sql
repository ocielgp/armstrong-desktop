create definer = root@`%` view sac_view_clientes as
select `o`.`_id`                                            AS `Orden`,
       cast(`o`.`createdAt` as date)                        AS `FechaOrden`,
       concat(concat(`c`.`name`, '-'), right(`c`.`_id`, 3)) AS `Cliente`,
       cast(`c`.`createdAt` as date)                        AS `FechaRegistro`
from (`coyotebd`.`customers` `c`
         left join `coyotebd`.`orders` `o` on ((`c`.`_id` = `o`.`id_customers`)));

