create definer = root@localhost trigger ADMINS_BEFORE_UPDATE
    before update
    on admins
    for each row
BEGIN
	IF(OLD.updatedBy IS NULL) THEN
		INSERT INTO ADMINS_AUDIT(action, updatedAt, updatedBy, username, password, idMember, idRole) VALUE (
			'CREATE',
            OLD.createdAt,
            OLD.createdBy,
            OLD.username,
            OLD.password,
            OLD.idMember,
            OLD.idRole
		);
    END IF;
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
    SET NEW.updatedAt = NOW();
    INSERT INTO ADMINS_AUDIT(action, updatedAt, updatedBy, username, password, idMember, idRole) VALUE (
		@action,
		NEW.createdAt,
		NEW.createdBy,
		NEW.username,
		NEW.password,
		NEW.idMember,
		NEW.idRole
	);
END;

