create definer = root@localhost trigger MEMBERS_BEFORE_UPDATE
    before update
    on members
    for each row
BEGIN
	IF(OLD.updatedBy IS NULL) THEN
		INSERT INTO MEMBERS_AUDIT(action, updatedAt, updatedBy, idMember, name, lastName, gender, notes, access, idGym) VALUE (
			'CREATE',
            OLD.createdAt,
            OLD.createdBy,
            OLD.idMember,
            OLD.name,
            OLD.lastName,
            OLD.gender,
            OLD.notes,
            OLD.access,
            OLD.idGym
		);
    END IF;
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
    SET NEW.updatedAt = NOW();
    INSERT INTO MEMBERS_AUDIT(action, updatedAt, updatedBy, idMember, name, lastName, gender, notes, access, idGym) VALUE (
		@action,
		NEW.updatedAt,
		NEW.updatedBy,
		NEW.idMember,
		NEW.name,
		NEW.lastName,
		NEW.gender,
		NEW.notes,
		NEW.access,
		NEW.idGym
	);
END;

