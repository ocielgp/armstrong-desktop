create definer = root@localhost trigger MEMBERSHIPS_BEFORE_UPDATE
    before update
    on memberships
    for each row
BEGIN
	IF(OLD.updatedBy IS NULL) THEN
    INSERT INTO MEMBERSHIPS_AUDIT(action, updatedAt, updatedBy, idMembership, name, price, monthly) VALUE (
		'CREATE',
        OLD.createdAt,
        OLD.createdBy,
        OLD.idMembership,
        OLD.name,
        OLD.price,
        OLD.monthly
	);
    END IF;
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
	SET NEW.updatedAt = NOW();
    INSERT INTO MEMBERSHIPS_AUDIT(action, updatedAt, updatedBy, idMembership, name, price, monthly) VALUE (
		@action,
        NEW.updatedAt,
        NEW.updatedBy,
        NEW.idMembership,
        NEW.name,
        NEW.price,
        NEW.monthly
	);
END;

