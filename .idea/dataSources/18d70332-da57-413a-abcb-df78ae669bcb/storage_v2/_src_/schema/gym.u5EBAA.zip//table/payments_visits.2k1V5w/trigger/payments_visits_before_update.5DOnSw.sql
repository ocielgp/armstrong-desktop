create definer = root@localhost trigger PAYMENTS_VISITS_BEFORE_UPDATE
    before update
    on payments_visits
    for each row
BEGIN
	IF(OLD.updatedBy IS NULL) THEN
    INSERT INTO PAYMENTS_VISITS_AUDIT(action, updatedAt, updatedBy, idPaymentVisit, price, idGym) VALUE (
		'CREATE',
        OLD.createdAt,
        OLD.createdBy,
        OLD.idPaymentVisit,
        OLD.price,
        OLD.idGym
	);
    END IF;
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
	SET NEW.updatedAt = NOW();
    INSERT INTO PAYMENTS_VISITS_AUDIT(action, updatedAt, updatedBy, idPaymentVisit, price, idGym) VALUE (
		@action,
        NEW.updatedAt,
        NEW.updatedBy,
        NEW.idPaymentVisit,
        NEW.price,
        NEW.idGym
	);
END;

