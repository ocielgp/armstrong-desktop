create definer = root@localhost trigger PAYMENTS_MEMBERSHIPS_BEFORE_UPDATE
    before update
    on payments_memberships
    for each row
BEGIN
	IF (OLD.updatedBy IS NULL) THEN
		INSERT INTO PAYMENTS_MEMBERSHIPS_AUDIT(action, updatedAt, updatedBy, idPaymentMembership, months, price, startDateTime, endDateTime, idGym, idMember, idMembership) VALUE (
			'CREATE',
			OLD.createdAt,
			OLD.createdBy,
			OLD.idPaymentMembership,
			OLD.months,
			OLD.price,
			OLD.startDateTime,
			OLD.endDateTime,
			OLD.idGym,
			OLD.idMember,
			OLD.idMembership
		);
    END IF;
	IF (NEW.flag = 0) THEN
		SET @action = 'DELETE';
	ELSE
		SET @action = 'UPDATE';
	END IF;
    SET NEW.updatedAt = NOW();
	INSERT INTO PAYMENTS_MEMBERSHIPS_AUDIT(action, updatedAt, updatedBy, idPaymentMembership, months, price, startDateTime, endDateTime, idGym, idMember, idMembership) VALUE (
		@action,
		NEW.updatedAt,
		NEW.updatedBy,
		NEW.idPaymentMembership,
		NEW.months,
		NEW.price,
		NEW.startDateTime,
		NEW.endDateTime,
		NEW.idGym,
		NEW.idMember,
		NEW.idMembership
	);
END;

