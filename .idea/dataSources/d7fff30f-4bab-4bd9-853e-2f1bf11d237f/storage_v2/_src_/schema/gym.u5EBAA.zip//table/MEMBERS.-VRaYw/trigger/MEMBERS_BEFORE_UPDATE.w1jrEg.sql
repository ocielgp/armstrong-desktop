create definer = ociel@`%` trigger MEMBERS_BEFORE_UPDATE
    before update
    on MEMBERS
    for each row
BEGIN
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
    SET NEW.updatedAt = NOW();
    INSERT INTO MEMBERS_AUDIT(idMember, dateTime, idAdmin, name, lastName, gender, notes, access, idGym, flag, action) VALUE (
                                                                                           OLD.idMember,
                                                                                           OLD.updatedAt,
                                                                                           OLD.updatedBy,
                                                                                           OLD.name,
                                                                                           OLD.lastName,
                                                                                           OLD.gender,
                                                                                           OLD.notes,
                                                                                           OLD.access,
                                                                                           OLD.idGym,
                                                                                           OLD.flag,
                                                                                           @action
        );
END;

