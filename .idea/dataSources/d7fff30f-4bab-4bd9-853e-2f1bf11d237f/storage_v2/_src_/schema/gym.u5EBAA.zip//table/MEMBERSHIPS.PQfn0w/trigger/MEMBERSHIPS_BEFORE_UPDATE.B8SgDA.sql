create definer = ociel@`%` trigger MEMBERSHIPS_BEFORE_UPDATE
    before update
    on MEMBERSHIPS
    for each row
BEGIN
	IF (NEW.flag = 0) THEN
        SET @action = 'DELETE';
    ELSE
        SET @action = 'UPDATE';
    END IF;
	SET NEW.updatedAt = NOW();
    INSERT INTO MEMBERSHIPS_AUDIT(idMembership, dateTime, idAdmin, name, price, monthly, idAdmin, flag, action) VALUE (
                                                                                           OLD.idMembership,
                                                                                           OLD.updatedAt,
                                                                                           OLD.updatedBy,
                                                                                           OLD.name,
                                                                                           OLD.price,
                                                                                           OLD.monthly,
                                                                                           OLD.flag,
                                                                                           @action
        );
END;

